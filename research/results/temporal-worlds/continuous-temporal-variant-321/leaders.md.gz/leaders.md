## Variant 12514: 5043 living, 34147 births

Harvest 15318581.453125, depth 2.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (birth-result))
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local5 (target-tag (none))))
      (storage-slope local5)
    )
  )
)
```

## Variant 12287: 2441 living, 12360 births

Harvest 9036709.28515625, depth 2.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local3 (target-tag (none))))
      (storage-slope (memory m5))
    )
  )
)
```

## Variant 27494: 1666 living, 2290 births

Harvest 1366567.05859375, depth 2.

```lisp
(seq
  (photosynthesize)
  (split)
  (do
    (attack
      (nearest-corpse)
      (*
        (+ (color) (target-color (nearest-corpse)))
        (target-storage (none))
      )
    )
    (photosynthesize)
  )
)
```

## Variant 11184: 1201 living, 7432 births

Harvest 5523746.625, depth 2.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local2 (target-tag (none))))
      (storage-slope (memory m5))
    )
  )
)
```

## Variant 21623: 1085 living, 2338 births

Harvest 1648550.47265625, depth 1.

```lisp
(seq
  (do (photosynthesize) (seq (nop) (nop) (split)))
  (move (/ (storage) (max (age) (memory m7))))
  (photosynthesize)
  (state ((state6 (abs 0)))
    (if
      (and true (> (sunlight-slope) (tag)))
      (eat)
      (set m2 (birth-result))
    )
  )
)
```

## Variant 11723: 903 living, 1929 births

Harvest 1474964.171875, depth 1.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local5 (target-tag (none))))
      (storage-slope local5)
    )
  )
)
```

## Variant 19250: 858 living, 3099 births

Harvest 2675805.1015625, depth 1.

```lisp
(seq
  (do (photosynthesize) (seq (eat) (nop) (split)))
  (move (/ (storage) (max (age) (memory m5))))
  (photosynthesize)
  (state ((state6 (abs 0)))
    (if
      (and true (> (sunlight-slope) (tag)))
      (eat)
      (set m2 (birth-result))
    )
  )
)
```

## Variant 27035: 798 living, 899 births

Harvest 774886.01171875, depth 0.

```lisp
(seq
  (do
    (photosynthesize)
    (seq
      (shield (/ (linked_temperature) (rotation)))
      (tag-set (age))
    )
  )
  (split)
  (photosynthesize)
)
```

## Variant 12906: 770 living, 4247 births

Harvest 1989527.65234375, depth 2.

```lisp
(seq
  (photosynthesize)
  (split)
  (move
    (- (target-distance (nearest-cell)) (crowding))
  )
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local5 (target-tag (none))))
      (storage-slope local5)
    )
  )
)
```

## Variant 12604: 708 living, 4505 births

Harvest 2929035.27734375, depth 1.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local5 (target-tag (none))))
      (storage-slope local5)
    )
  )
)
```

## Variant 25797: 691 living, 2373 births

Harvest 1358630.671875, depth 2.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (let ((local2 (max
      (temperature)
      (mod (target-tag (self)) (linked_temperature))
    )))
    (nop)
  )
)
```

## Variant 25955: 680 living, 852 births

Harvest 623788.10546875, depth 2.

```lisp
(seq
  (photosynthesize)
  (if false (split) (eat))
  (eat)
  (seq
    (let ((local1 (linked_temperature)))
      (split)
    )
    (photosynthesize)
  )
  (unlink (bond c1))
  (photosynthesize)
)
```
