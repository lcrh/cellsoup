## Variant 10264: 2483 living, 38186 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (photosynthesize)
  (move (max (sunlight) (temperature)))
  (eat)
  (bud)
  (photosynthesize)
)
```

## Variant 11770: 1042 living, 20817 births

Harvest 11029793.31640625, depth 1.

```lisp
(seq
  (photosynthesize)
  (move (max (sunlight) (temperature)))
  (eat)
  (bud)
  (photosynthesize)
)
```

## Variant 11091: 551 living, 10165 births

Harvest 5268766.90234375, depth 2.

```lisp
(seq
  (photosynthesize)
  (move
    (max
      (mod
        (lag
          (abs
            (state ((state1 (- (age) (generation))))
              (linked_temperature)
            )
          )
        )
        (tag)
      )
      (temperature)
    )
  )
  (eat)
  (bud)
  (photosynthesize)
)
```

## Variant 15158: 281 living, 2136 births

Harvest 1024107.30859375, depth 2.

```lisp
(seq
  (photosynthesize)
  (move (max (delta (sunlight)) (temperature)))
  (eat)
  (bud)
  (photosynthesize)
)
```

## Variant 13287: 213 living, 3763 births

Harvest 2160250.92578125, depth 2.

```lisp
(seq
  (photosynthesize)
  (move (max (sunlight) (temperature)))
  (eat)
  (give
    (do (bud) (nearest-corpse))
    (target-distance
      (state ((state1 (energy)))
        (if
          (state ((state1 (energy)))
            false
          )
          (do (photosynthesize) (self))
          (if false (self) (none))
        )
      )
    )
  )
  (photosynthesize)
)
```

## Variant 10871: 116 living, 1969 births

Harvest 1121325.86328125, depth 2.

```lisp
(seq
  (photosynthesize)
  (move (max (age) (temperature)))
  (eat)
  (bud)
  (photosynthesize)
)
```

## Variant 12094: 116 living, 3507 births

Harvest 1580277.4453125, depth 1.

```lisp
(seq
  (photosynthesize)
  (move (max (sunlight) (temperature)))
  (eat)
  (bud)
  (photosynthesize)
)
```

## Variant 35023: 104 living, 103 births

Harvest 9265.9296875, depth 3.

```lisp
(seq
  (if (alive (self)) (photosynthesize) (bud))
  (if
    (=
      (lag
        (/
          (target-bearing
            (scan-color (color) (sunlight))
          )
          (energy)
        )
      )
      (+ (linked_temperature) 0.10000000149011612)
    )
    (bud)
    (bud)
  )
  (if
    (kin (self))
    (move (sunlight))
    (unlink (nearest-cell))
  )
  (photosynthesize)
  (eat)
)
```

## Variant 14895: 61 living, 1428 births

Harvest 783434.34375, depth 1.

```lisp
(seq
  (photosynthesize)
  (move
    (abs
      (+
        (* (temperature) (rotation))
        (target-bearing (if false (self) (self)))
      )
    )
  )
  (eat)
  (bud)
  (photosynthesize)
)
```

## Variant 24538: 56 living, 105 births

Harvest 40565.4921875, depth 3.

```lisp
(seq
  (if (alive (self)) (photosynthesize) (bud))
  (if
    (=
      (lag
        (/
          (target-bearing
            (scan-color (color) (sunlight))
          )
          (energy)
        )
      )
      (+ (linked_temperature) 0.10000000149011612)
    )
    (bud)
    (bud)
  )
  (if (kin (self)) (move (energy)) (nop))
  (photosynthesize)
  (eat)
)
```

## Variant 33227: 43 living, 44 births

Harvest 12409.38671875, depth 5.

```lisp
(seq
  (state ((state4 (rotation)))
    (eat)
  )
  (seq
    (eat)
    (photosynthesize)
    (send
      (scan (temperature) (sunlight))
      c0
      (target-bearing (nearest-corpse))
    )
    (turn (birth-result))
    (photosynthesize)
  )
  (mobilize 1.8152998685836792)
  (split)
  (photosynthesize)
)
```

## Variant 16830: 36 living, 607 births

Harvest 325429.51171875, depth 1.

```lisp
(seq
  (photosynthesize)
  (move (max (sunlight) (temperature)))
  (eat)
  (bud)
  (photosynthesize)
)
```
