## Variant 14425: 16883 living, 88811 births

Harvest 16777215.99609375, depth 2.

```lisp
(seq
  (seq
    (seq (turn (memory m6)) (move (tag)))
    (eat)
    (photosynthesize)
  )
  (tag-set (target-bearing (nearest-cell)))
  (do (photosynthesize) (split))
  (mobilize (target-energy (none)))
  (photosynthesize)
)
```

## Variant 12756: 1974 living, 7229 births

Harvest 3547475.78515625, depth 1.

```lisp
(seq
  (seq
    (seq (if true (nop) (nop)) (move (tag)))
    (eat)
    (photosynthesize)
  )
  (tag-set (target-bearing (nearest-cell)))
  (do (photosynthesize) (split))
  (mobilize (target-energy (none)))
  (photosynthesize)
)
```

## Variant 10556: 1951 living, 30727 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (seq
    (seq (if true (nop) (nop)) (move (tag)))
    (eat)
    (photosynthesize)
  )
  (tag-set (target-bearing (nearest-cell)))
  (do (photosynthesize) (split))
  (mobilize (target-energy (none)))
  (photosynthesize)
)
```

## Variant 14530: 831 living, 3531 births

Harvest 1805823.32421875, depth 1.

```lisp
(seq
  (seq
    (seq (if true (nop) (nop)) (move (tag)))
    (eat)
    (photosynthesize)
  )
  (tag-set (target-bearing (nearest-cell)))
  (do (photosynthesize) (split))
  (mobilize (target-energy (none)))
  (photosynthesize)
)
```

## Variant 15246: 490 living, 2945 births

Harvest 1304185.859375, depth 2.

```lisp
(seq
  (seq
    (seq (if true (nop) (nop)) (move (tag)))
    (link
      (state ((state1 (storage)))
        (do (link (none)) (self))
      )
    )
  )
  (tag-set (target-bearing (nearest-cell)))
  (do (photosynthesize) (split))
  (mobilize (target-energy (none)))
  (photosynthesize)
)
```

## Variant 9561: 403 living, 11277 births

Harvest 6793333.16796875, depth 2.

```lisp
(seq
  (seq
    (photosynthesize)
    (eat)
    (photosynthesize)
    (move (color))
    (do (split) (photosynthesize))
  )
  (eat)
  (move (temperature))
)
```

## Variant 25528: 212 living, 211 births

Harvest 75093.93359375, depth 3.

```lisp
(seq
  (attack (self) (linked_temperature))
  (eat)
  (tag-set (target-bearing (nearest-cell)))
  (do (photosynthesize) (split))
  (seq
    (set m4 (target-energy (nearest-cell)))
    (photosynthesize)
  )
  (unlink
    (state ((state4 (crowding)))
      (nearest-corpse)
    )
  )
  (photosynthesize)
)
```

## Variant 14171: 172 living, 1024 births

Harvest 534991.0234375, depth 1.

```lisp
(seq
  (seq
    (seq (if true (nop) (nop)) (move (tag)))
    (eat)
    (photosynthesize)
  )
  (tag-set (target-bearing (nearest-cell)))
  (do (photosynthesize) (split))
  (mobilize (target-energy (none)))
  (photosynthesize)
)
```

## Variant 26463: 108 living, 206 births

Harvest 101722.41796875, depth 3.

```lisp
(seq
  (attack (self) (linked_temperature))
  (eat)
  (tag-set (target-bearing (nearest-cell)))
  (do (photosynthesize) (split))
  (link
    (do
      (move
        (target-tag
          (scan-color (linked_temperature) (tag))
        )
      )
      (self)
    )
  )
  (unlink
    (state ((state4 (crowding)))
      (nearest-corpse)
    )
  )
  (photosynthesize)
)
```

## Variant 25288: 57 living, 83 births

Harvest 65904.41015625, depth 3.

```lisp
(seq
  (seq (photosynthesize) (split))
  (move
    (target-storage
      (state ((state2 (age)))
        (nearest-cell)
      )
    )
  )
  (unlink (if false (self) (nearest-cell)))
  (do (seq (eat) (photosynthesize)) (nop))
  (link (self))
)
```

## Variant 14152: 37 living, 268 births

Harvest 172779.1640625, depth 3.

```lisp
(seq
  (seq
    (photosynthesize)
    (eat)
    (photosynthesize)
    (move (color))
    (do (split) (photosynthesize))
  )
  (eat)
  (move (tag))
)
```

## Variant 26517: 33 living, 33 births

Harvest 4319.0234375, depth 3.

```lisp
(seq
  (seq (photosynthesize) (split))
  (move
    (target-storage
      (state ((state7 (age)))
        (nearest-cell)
      )
    )
  )
  (unlink (if false (self) (nearest-cell)))
  (do (seq (eat) (photosynthesize)) (nop))
  (link (nearest-corpse))
)
```
