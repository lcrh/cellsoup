## Variant 12218: 29781 living, 136317 births

Harvest 16777215.99609375, depth 2.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (none))
  (photosynthesize)
  (turn
    (+
      (storage-slope (rotation))
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link
    (do
      (mobilize (energy))
      (do
        (eat)
        (state ((state7 (bonds)))
          (none)
        )
      )
    )
  )
)
```

## Variant 10121: 1751 living, 85499 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (none))
  (photosynthesize)
  (turn
    (+
      (receive c1)
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link
    (do
      (mobilize (energy))
      (do
        (eat)
        (state ((state7 (bonds)))
          (none)
        )
      )
    )
  )
)
```

## Variant 22406: 164 living, 476 births

Harvest 181620.4296875, depth 3.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (nearest-corpse))
  (photosynthesize)
  (turn
    (+
      (storage-slope (rotation))
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link
    (do
      (mobilize (energy))
      (do
        (eat)
        (state ((state7 (bonds)))
          (none)
        )
      )
    )
  )
)
```

## Variant 10635: 147 living, 4000 births

Harvest 1595072.32421875, depth 1.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (none))
  (photosynthesize)
  (turn
    (+
      (receive c1)
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link
    (do
      (mobilize (energy))
      (do
        (eat)
        (state ((state7 (bonds)))
          (none)
        )
      )
    )
  )
)
```

## Variant 10634: 113 living, 9198 births

Harvest 3707953.03515625, depth 2.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (none))
  (photosynthesize)
  (turn
    (+
      (receive c1)
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link
    (do
      (mobilize (energy))
      (do
        (eat)
        (state ((state7 (linked_storage)))
          (none)
        )
      )
    )
  )
)
```

## Variant 29690: 80 living, 79 births

Harvest 22448.58984375, depth 4.

```lisp
(seq
  (attack (self) (* (energy) (target-bonds (self))))
  (do
    (photosynthesize)
    (do
      (if
        (=
          (random
            (let ((local0 (energy)))
              (storage)
            )
          )
          (target-bearing (scan (age) (temperature)))
        )
        (link (nearest-cell))
        (nop)
      )
      (state ((state3 (tag)))
        (split)
      )
    )
  )
  (photosynthesize)
  (eat)
)
```

## Variant 26459: 75 living, 133 births

Harvest 48039.921875, depth 3.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (none))
  (photosynthesize)
  (turn
    (+
      (storage-slope (rotation))
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link
    (do
      (mobilize (energy))
      (do
        (eat)
        (state ((state7 (sunlight-slope)))
          (none)
        )
      )
    )
  )
)
```

## Variant 24368: 62 living, 122 births

Harvest 43777.09765625, depth 2.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (none))
  (photosynthesize)
  (turn
    (+
      (storage-slope (rotation))
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link
    (do
      (mobilize (energy))
      (do
        (eat)
        (state ((state7 (bonds)))
          (none)
        )
      )
    )
  )
)
```

## Variant 23556: 60 living, 110 births

Harvest 43349.765625, depth 3.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (none))
  (photosynthesize)
  (turn
    (+
      (storage-slope (rotation))
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link (do (mobilize (energy)) (do (eat) (none))))
)
```

## Variant 29267: 58 living, 96 births

Harvest 31560.06640625, depth 2.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (none))
  (photosynthesize)
  (turn
    (+
      (storage-slope (rotation))
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link
    (do
      (mobilize (energy))
      (do
        (eat)
        (state ((state7 (bonds)))
          (none)
        )
      )
    )
  )
)
```

## Variant 19826: 40 living, 399 births

Harvest 143315.0234375, depth 2.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (none))
  (photosynthesize)
  (turn
    (+
      (receive c1)
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link
    (do
      (mobilize (energy))
      (do
        (eat)
        (state ((state7 (sunlight)))
          (none)
        )
      )
    )
  )
)
```

## Variant 10855: 31 living, 1285 births

Harvest 516699.52734375, depth 2.

```lisp
(seq
  (do (photosynthesize) (move 1))
  (split)
  (link (none))
  (photosynthesize)
  (turn
    (+
      (receive c1)
      (min
        (target-bearing (nearest-corpse))
        (storage-slope (energy))
      )
    )
  )
  (link
    (do
      (mobilize (energy))
      (do
        (eat)
        (state ((state4 (bonds)))
          (none)
        )
      )
    )
  )
)
```
