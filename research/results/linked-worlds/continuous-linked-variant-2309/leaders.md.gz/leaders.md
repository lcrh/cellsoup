## Variant 8681: 5258 living, 56585 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (eat)
  (color-set (target-bonds (scan (bonds) (tag))))
  (do (photosynthesize) (split))
  (state ((state3 (target-bearing (none))))
    (photosynthesize)
  )
  (seq
    (set m4 (bonds))
    (tag-set (linked_temperature))
  )
  (photosynthesize)
  (move (max (sunlight) (energy)))
)
```

## Variant 25476: 3012 living, 4061 births

Harvest 2369146.79296875, depth 3.

```lisp
(seq
  (seq
    (eat)
    (move 0.10000000149011612)
    (color-set (bonds))
    (state ((state2 0.75))
      (if
        (<
          (target-temperature
            (do (photosynthesize) (none))
          )
          (random
            (target-storage
              (scan
                (linked_storage)
                (* (sunlight-slope) (bonds))
              )
            )
          )
        )
        (photosynthesize)
        (photosynthesize)
      )
    )
  )
  (do
    (photosynthesize)
    (seq (split) (photosynthesize))
  )
)
```

## Variant 22355: 2411 living, 4295 births

Harvest 3856127.40625, depth 2.

```lisp
(seq
  (if
    (kin (do (photosynthesize) (none)))
    (photosynthesize)
    (mobilize (sunlight-slope))
  )
  (do (split) (seq (eat) (photosynthesize)))
  (nop)
  (attack
    (nearest-corpse)
    (+
      (target-bearing (nearest-cell))
      (target-temperature (nearest-cell))
    )
  )
)
```

## Variant 20600: 1202 living, 1794 births

Harvest 1520567.7578125, depth 2.

```lisp
(seq
  (eat)
  (color-set (target-bonds (scan (bonds) (tag))))
  (do (photosynthesize) (split))
  (state ((state3 (target-bearing (none))))
    (photosynthesize)
  )
  (color-set (color))
)
```

## Variant 21816: 806 living, 2432 births

Harvest 1129466.0234375, depth 2.

```lisp
(seq
  (if
    (kin (do (photosynthesize) (none)))
    (photosynthesize)
    (mobilize (sunlight-slope))
  )
  (do
    (split)
    (seq
      (state ((state2 (sunlight-slope)))
        (eat)
      )
      (photosynthesize)
    )
  )
  (nop)
  (attack
    (nearest-corpse)
    (storage-bearing (listen c2))
  )
)
```

## Variant 21389: 593 living, 986 births

Harvest 674465.12890625, depth 2.

```lisp
(seq
  (eat)
  (color-set (target-bonds (scan (bonds) (tag))))
  (do (photosynthesize) (split))
  (state ((state3 (target-bearing (none))))
    (photosynthesize)
  )
  (photosynthesize)
)
```

## Variant 23835: 526 living, 876 births

Harvest 598185.25390625, depth 2.

```lisp
(seq
  (seq (eat) (set m4 (sunlight)))
  (photosynthesize)
  (seq (split) (do (nop) (photosynthesize)))
  (tag-set (abs (target-storage (self))))
)
```

## Variant 14987: 510 living, 4156 births

Harvest 2126620.5, depth 1.

```lisp
(seq
  (if
    (kin (do (photosynthesize) (none)))
    (photosynthesize)
    (mobilize (sunlight-slope))
  )
  (do
    (split)
    (seq
      (state ((state4 (sunlight-slope)))
        (eat)
      )
      (photosynthesize)
    )
  )
  (nop)
  (attack
    (nearest-corpse)
    (+
      (target-bearing (nearest-cell))
      (target-temperature (nearest-cell))
    )
  )
)
```

## Variant 23831: 475 living, 719 births

Harvest 285455.29296875, depth 3.

```lisp
(seq
  (eat)
  (seq
    (move
      (*
        (age)
        (min
          (* (sunlight-slope) (storage))
          (target-storage (self))
        )
      )
    )
    (unlink (none))
  )
  (photosynthesize)
  (seq
    (seq (split) (do (nop) (photosynthesize)))
    (eat)
  )
  (bud)
  (photosynthesize)
)
```

## Variant 24024: 468 living, 3707 births

Harvest 1966258.40625, depth 3.

```lisp
(seq
  (seq
    (eat)
    (move 0.10000000149011612)
    (color-set (bonds))
    (state ((state2 0.75))
      (if
        (<
          (target-temperature
            (do (photosynthesize) (none))
          )
          (random
            (target-storage
              (scan
                (linked_storage)
                (* (sunlight-slope) (bonds))
              )
            )
          )
        )
        (photosynthesize)
        (photosynthesize)
      )
    )
  )
  (do
    (photosynthesize)
    (seq (split) (photosynthesize))
  )
)
```

## Variant 24356: 439 living, 613 births

Harvest 205706.4140625, depth 2.

```lisp
(seq
  (seq
    (eat)
    (move 0.10000000149011612)
    (unlink (none))
    (state ((state2 0.75))
      (if
        (<
          (target-temperature
            (do (photosynthesize) (none))
          )
          (random
            (target-storage
              (scan
                (linked_storage)
                (* (sunlight-slope) (bonds))
              )
            )
          )
        )
        (photosynthesize)
        (photosynthesize)
      )
    )
  )
  (do
    (photosynthesize)
    (seq (split) (photosynthesize))
  )
)
```

## Variant 23048: 431 living, 1195 births

Harvest 772737.84375, depth 1.

```lisp
(seq
  (if
    (kin (do (photosynthesize) (none)))
    (photosynthesize)
    (mobilize (sunlight-slope))
  )
  (do
    (split)
    (seq
      (state ((state4 (sunlight-slope)))
        (eat)
      )
      (photosynthesize)
    )
  )
  (nop)
  (attack
    (nearest-corpse)
    (+
      (target-bearing (nearest-cell))
      (target-temperature (nearest-cell))
    )
  )
)
```
