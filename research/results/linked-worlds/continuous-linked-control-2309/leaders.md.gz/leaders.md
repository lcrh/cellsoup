## Variant 22821: 1347 living, 2366 births

Harvest 950163.74609375, depth 1.

```lisp
(seq
  (photosynthesize)
  (move (target-energy (nearest-cell)))
  (do (give (none) (temperature)) (photosynthesize))
  (do (eat) (seq (bud) (unlink (nearest-corpse))))
  (color-set (birth-result))
  (do
    (do (turn (random (sunlight))) (tag-set (bonds)))
    (photosynthesize)
  )
)
```

## Variant 8748: 915 living, 8584 births

Harvest 2779765.875, depth 1.

```lisp
(seq
  (set m2 (generation))
  (photosynthesize)
  (seq (tag-set (linked_storage)) (move 90))
  (seq
    (state ((state0 (sunlight-bearing)))
      (state ((state3 (target-storage (none))))
        (eat)
      )
    )
    (split)
    (unlink (self))
  )
  (photosynthesize)
)
```

## Variant 21419: 742 living, 3291 births

Harvest 1880373.46484375, depth 1.

```lisp
(seq
  (if
    (alive
      (let ((local4 (sunlight-slope)))
        (self)
      )
    )
    (eat)
    (photosynthesize)
  )
  (move (do (photosynthesize) (energy)))
  (split)
  (turn 0.25)
  (tag-set
    (state ((state3 (sunlight)))
      (let ((local3 (rotation)))
        (linked_temperature)
      )
    )
  )
  (state ((state2 (linked_storage)))
    (photosynthesize)
  )
)
```

## Variant 20464: 664 living, 2369 births

Harvest 1310072.6171875, depth 1.

```lisp
(seq
  (if
    (alive
      (let ((local4 (sunlight-slope)))
        (self)
      )
    )
    (eat)
    (photosynthesize)
  )
  (move (do (photosynthesize) (energy)))
  (split)
  (turn 0.25)
  (tag-set
    (state ((state3 (sunlight)))
      (let ((local3 (rotation)))
        (linked_temperature)
      )
    )
  )
  (state ((state2 (linked_storage)))
    (photosynthesize)
  )
)
```

## Variant 13655: 583 living, 1844 births

Harvest 885962.11328125, depth 2.

```lisp
(seq
  (set m2 (generation))
  (photosynthesize)
  (tag-set
    (/
      (abs (min (storage) (rotation)))
      (sunlight-slope)
    )
  )
  (seq
    (state ((state0 (sunlight-bearing)))
      (state ((state3 (target-storage (none))))
        (eat)
      )
    )
    (split)
    (unlink (self))
  )
  (photosynthesize)
)
```

## Variant 22741: 580 living, 849 births

Harvest 548294.88671875, depth 1.

```lisp
(seq
  (unlink (do (photosynthesize) (nearest-corpse)))
  (set m7 (sunlight))
  (bud)
  (eat)
  (mobilize (sunlight))
  (turn 0.25)
  (tag-set
    (state ((state3 (sunlight)))
      (/ (tag) (birth-result))
    )
  )
  (state ((state2 (linked_storage)))
    (photosynthesize)
  )
)
```

## Variant 13006: 543 living, 3382 births

Harvest 1256883.44140625, depth 2.

```lisp
(seq
  (set m2 (generation))
  (photosynthesize)
  (seq (tag-set (linked_storage)) (move 90))
  (seq
    (state ((state6 (sunlight-bearing)))
      (state ((state3 (target-storage (none))))
        (eat)
      )
    )
    (split)
    (unlink (self))
  )
  (photosynthesize)
)
```

## Variant 9217: 497 living, 2878 births

Harvest 1313345.82421875, depth 1.

```lisp
(seq
  (if
    (alive
      (let ((local4 (sunlight-slope)))
        (self)
      )
    )
    (eat)
    (photosynthesize)
  )
  (move (do (photosynthesize) (energy)))
  (split)
  (turn 0.25)
  (tag-set
    (state ((state3 (sunlight)))
      (let ((local3 (rotation)))
        (linked_temperature)
      )
    )
  )
  (state ((state2 (linked_storage)))
    (photosynthesize)
  )
)
```

## Variant 19156: 470 living, 730 births

Harvest 298663.3125, depth 2.

```lisp
(seq
  (if
    (alive
      (let ((local4 (sunlight-slope)))
        (self)
      )
    )
    (eat)
    (photosynthesize)
  )
  (move (do (photosynthesize) (rotation)))
  (split)
  (turn 0.25)
  (tag-set
    (state ((state3 (sunlight)))
      (let ((local3 (rotation)))
        2
      )
    )
  )
  (state ((state2 (linked_storage)))
    (photosynthesize)
  )
)
```

## Variant 22011: 439 living, 1409 births

Harvest 643482.91015625, depth 2.

```lisp
(seq
  (unlink (none))
  (photosynthesize)
  (split)
  (move
    (storage-bearing
      (target-temperature (scan (energy) (storage)))
    )
  )
  (link
    (state ((state2 (receive c1)))
      (bond c0)
    )
  )
  (let ((local1 (target-bonds
      (if (or false true) (none) (nearest-cell))
    )))
    (photosynthesize)
  )
)
```

## Variant 16509: 404 living, 3100 births

Harvest 1094269.7578125, depth 2.

```lisp
(seq
  (seq (photosynthesize) (move (energy)))
  (split)
  (link (self))
  (eat)
  (photosynthesize)
)
```

## Variant 23702: 375 living, 583 births

Harvest 316920.60546875, depth 1.

```lisp
(seq
  (unlink (none))
  (photosynthesize)
  (split)
  (let ((local1 (listen c2)))
    (unlink (nearest-cell))
  )
  (link
    (state ((state2 (receive c3)))
      (bond c0)
    )
  )
  (let ((local1 (target-bonds
      (if
        (or false true)
        (nearest-cell)
        (nearest-cell)
      )
    )))
    (photosynthesize)
  )
)
```
