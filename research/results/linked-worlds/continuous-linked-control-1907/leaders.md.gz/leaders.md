## Variant 2069: 3524 living, 11752 births

Harvest 9031687.5234375, depth 0.

```lisp
(seq
  (photosynthesize)
  (split)
  (state ((state2 (storage)))
    (give (nearest-corpse) (sunlight-bearing))
  )
  (photosynthesize)
  (seq (shield (receive c3)) (eat))
  (let ((local4 360))
    (unlink (bond c2))
  )
)
```

## Variant 19201: 2958 living, 4214 births

Harvest 4560600.58203125, depth 1.

```lisp
(seq
  (give (nearest-corpse) 0.75)
  (nop)
  (photosynthesize)
  (shield (birth-result))
  (eat)
  (mobilize
    (mod
      (listen c2)
      (do (seq (split) (photosynthesize)) -1)
    )
  )
)
```

## Variant 25874: 2905 living, 5067 births

Harvest 2246101.12890625, depth 2.

```lisp
(seq
  (mobilize (target-color (bond c0)))
  (move
    (*
      (target-bearing
        (do (photosynthesize) (nearest-corpse))
      )
      (generation)
    )
  )
  (tag-set (temperature))
  (eat)
  (turn (crowding))
  (move (temperature))
  (do (split) (seq (photosynthesize) (eat)))
)
```

## Variant 13130: 2452 living, 6480 births

Harvest 5718932.9375, depth 1.

```lisp
(seq
  (photosynthesize)
  (split)
  (state ((state2 (storage)))
    (give (nearest-corpse) (sunlight-bearing))
  )
  (photosynthesize)
  (seq
    (move
      (/
        (storage)
        (state ((state1 (energy)))
          (crowding)
        )
      )
    )
    (eat)
  )
  (let ((local4 360))
    (unlink (bond c2))
  )
)
```

## Variant 19490: 1683 living, 4241 births

Harvest 1876202.3125, depth 2.

```lisp
(seq
  (mobilize (target-color (bond c0)))
  (move
    (*
      (target-bearing
        (do (photosynthesize) (nearest-corpse))
      )
      (generation)
    )
  )
  (tag-set (temperature))
  (eat)
  (move (rotation))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do (split) (seq (photosynthesize) (eat)))
)
```

## Variant 13231: 1644 living, 2373 births

Harvest 2253066.6875, depth 1.

```lisp
(seq
  (photosynthesize)
  (split)
  (state ((state2 (storage)))
    (give (bond c1) (sunlight-bearing))
  )
  (photosynthesize)
  (seq (shield (receive c3)) (eat))
  (let ((local4 360))
    (unlink (bond c2))
  )
)
```

## Variant 12935: 1468 living, 3502 births

Harvest 3625723.3046875, depth 0.

```lisp
(seq
  (photosynthesize)
  (split)
  (state ((state2 (storage)))
    (give (nearest-corpse) (sunlight-bearing))
  )
  (photosynthesize)
  (seq (shield (receive c3)) (eat))
  (let ((local4 360))
    (unlink (bond c2))
  )
)
```

## Variant 14374: 1393 living, 3768 births

Harvest 1881270.1640625, depth 2.

```lisp
(seq
  (photosynthesize)
  (move (temperature))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do
    (seq
      (photosynthesize)
      (if
        (< (target-tag (nearest-corpse)) (bonds))
        (move (storage))
        (split)
      )
      (mobilize (target-color (bond c0)))
      (photosynthesize)
    )
    (seq (photosynthesize) (eat))
  )
)
```

## Variant 10814: 1205 living, 5988 births

Harvest 2642821.17578125, depth 1.

```lisp
(seq
  (photosynthesize)
  (move (temperature))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do (split) (seq (photosynthesize) (eat)))
)
```

## Variant 14854: 787 living, 4028 births

Harvest 1595971.5, depth 1.

```lisp
(seq
  (nop)
  (photosynthesize)
  (tag-set (temperature))
  (photosynthesize)
  (move (temperature))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do (split) (seq (photosynthesize) (eat)))
)
```

## Variant 22702: 678 living, 1975 births

Harvest 1417364.015625, depth 1.

```lisp
(seq
  (photosynthesize)
  (split)
  (state ((state2 (storage)))
    (give (nearest-corpse) (sunlight-bearing))
  )
  (photosynthesize)
  (seq (shield (receive c3)) (eat))
  (let ((local4 360))
    (set m7 (target-distance (bond c0)))
  )
)
```

## Variant 22544: 673 living, 914 births

Harvest 572477.77734375, depth 2.

```lisp
(seq
  (photosynthesize)
  (mobilize
    (target-shield
      (let ((local0 (random (target-storage (none)))))
        (state ((state3 (sunlight-bearing)))
          (nearest-corpse)
        )
      )
    )
  )
  (if
    (do (split) (if true false false))
    (store (energy))
    (seq
      (mobilize (memory m6))
      (give (do (photosynthesize) (nearest-corpse)) 0)
    )
  )
)
```
