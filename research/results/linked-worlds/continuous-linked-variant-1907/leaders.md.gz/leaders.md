## Variant 25156: 26050 living, 105444 births

Harvest 16777215.99609375, depth 2.

```lisp
(seq
  (photosynthesize)
  (do (color-set (sunlight-bearing)) (do (bud) (eat)))
  (give
    (state ((state4 (age)))
      (let ((local4 (if
          (not true)
          (min (sunlight-bearing) (sunlight))
          (target-temperature (none))
        )))
        (bond c1)
      )
    )
    (age)
  )
  (photosynthesize)
  (nop)
)
```

## Variant 12865: 937 living, 4180 births

Harvest 2347213.484375, depth 1.

```lisp
(seq
  (shield
    (abs
      (target-energy (do (photosynthesize) (none)))
    )
  )
  (bud)
  (eat)
  (move (temperature))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do
    (mobilize (receive c3))
    (seq (photosynthesize) (eat))
  )
)
```

## Variant 19059: 397 living, 2919 births

Harvest 1643292.87890625, depth 0.

```lisp
(seq
  (photosynthesize)
  (send
    (none)
    c0
    (target-temperature (nearest-corpse))
  )
  (split)
  (store (abs (abs (memory m2))))
  (move (linked_storage))
  (do (photosynthesize) (eat))
)
```

## Variant 17821: 287 living, 1057 births

Harvest 456245.14453125, depth 1.

```lisp
(seq
  (shield
    (abs
      (target-energy (do (photosynthesize) (none)))
    )
  )
  (bud)
  (eat)
  (move (temperature))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do
    (mobilize (receive c3))
    (seq (photosynthesize) (eat))
  )
)
```

## Variant 12088: 250 living, 2259 births

Harvest 1358845.7734375, depth 1.

```lisp
(seq
  (set m6 (random (storage)))
  (photosynthesize)
  (bud)
  (eat)
  (let ((local6 (+
      (memory m0)
      (target-color
        (state ((state4 (target-distance (nearest-corpse))))
          (bond c3)
        )
      )
    )))
    (photosynthesize)
  )
)
```

## Variant 17284: 215 living, 1409 births

Harvest 727331.81640625, depth 1.

```lisp
(seq
  (shield
    (abs
      (target-energy (do (photosynthesize) (none)))
    )
  )
  (bud)
  (eat)
  (move (temperature))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do
    (mobilize (receive c3))
    (seq (photosynthesize) (eat))
  )
)
```

## Variant 10716: 187 living, 1450 births

Harvest 1364483.0234375, depth 1.

```lisp
(seq
  (tag-set
    (random
      (if
        true
        (generation)
        (state ((state4 (storage)))
          (crowding)
        )
      )
    )
  )
  (photosynthesize)
  (do (photosynthesize) (move (memory m1)))
  (bud)
  (if
    (not true)
    (send (nearest-cell) c2 (sunlight-bearing))
    (eat)
  )
  (photosynthesize)
)
```

## Variant 13299: 177 living, 1991 births

Harvest 1150766.5, depth 1.

```lisp
(seq
  (shield
    (abs
      (target-energy (do (photosynthesize) (none)))
    )
  )
  (bud)
  (eat)
  (move (temperature))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do
    (mobilize (receive c3))
    (seq (photosynthesize) (eat))
  )
)
```

## Variant 13378: 165 living, 1760 births

Harvest 1032595.95703125, depth 1.

```lisp
(seq
  (shield
    (abs
      (target-energy (do (photosynthesize) (none)))
    )
  )
  (bud)
  (eat)
  (move (temperature))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do
    (mobilize (receive c3))
    (seq (photosynthesize) (eat))
  )
)
```

## Variant 16392: 161 living, 726 births

Harvest 336527.2578125, depth 1.

```lisp
(seq
  (shield
    (abs
      (target-energy (do (photosynthesize) (none)))
    )
  )
  (bud)
  (eat)
  (move (temperature))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do
    (mobilize (receive c3))
    (seq (photosynthesize) (eat))
  )
)
```

## Variant 18580: 154 living, 369 births

Harvest 274557.08984375, depth 1.

```lisp
(seq
  (tag-set
    (random
      (if
        true
        (generation)
        (state ((state4 (storage)))
          (crowding)
        )
      )
    )
  )
  (photosynthesize)
  (do (photosynthesize) (move (memory m1)))
  (bud)
  (if
    (not true)
    (send (nearest-cell) c2 (sunlight-bearing))
    (eat)
  )
  (photosynthesize)
)
```

## Variant 11324: 148 living, 1727 births

Harvest 1080404.4375, depth 1.

```lisp
(seq
  (shield
    (abs
      (target-energy (do (photosynthesize) (none)))
    )
  )
  (bud)
  (eat)
  (move (temperature))
  (state ((state0 (target-shield (none))))
    (eat)
  )
  (do
    (mobilize (receive c3))
    (seq (photosynthesize) (eat))
  )
)
```
