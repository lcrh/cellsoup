## Variant 29579: 13534 living, 18754 births

Harvest 6208675.37109375, depth 5.

```lisp
(seq
  (do (photosynthesize) (split))
  (move (crowding))
  (eat)
  (do (photosynthesize) (bud))
  (photosynthesize)
  (shield
    (target-color
      (if
        (do
          (color-set (target-energy (none)))
          (= (temperature) (color))
        )
        (nearest-cell)
        (state ((state0 (sunlight-slope)))
          (none)
        )
      )
    )
  )
)
```

## Variant 25359: 10749 living, 21858 births

Harvest 7510131.02734375, depth 4.

```lisp
(seq
  (do (photosynthesize) (split))
  (move (energy))
  (eat)
  (do (photosynthesize) (bud))
  (photosynthesize)
  (shield
    (target-color
      (if
        (do
          (color-set (target-energy (none)))
          (= (temperature) (color))
        )
        (nearest-cell)
        (state ((state0 (sunlight-slope)))
          (none)
        )
      )
    )
  )
)
```

## Variant 21757: 2181 living, 23093 births

Harvest 7147111.50390625, depth 2.

```lisp
(seq
  (move (do (eat) (color)))
  (attack (self) (storage-slope (temperature)))
  (do
    (photosynthesize)
    (unlink
      (state ((state7 (energy)))
        (nearest-cell)
      )
    )
  )
  (bud)
  (photosynthesize)
)
```

## Variant 28506: 730 living, 1377 births

Harvest 453470.8125, depth 5.

```lisp
(seq
  (do (photosynthesize) (split))
  (move (energy))
  (eat)
  (do (photosynthesize) (bud))
  (photosynthesize)
  (shield
    (target-color
      (if
        (do
          (color-set (target-energy (none)))
          (= (temperature) (color))
        )
        (nearest-cell)
        (none)
      )
    )
  )
)
```

## Variant 33574: 304 living, 335 births

Harvest 85904.9375, depth 2.

```lisp
(seq
  (if
    (= (sunlight-bearing) (sunlight-bearing))
    (seq (photosynthesize) (split))
    (move (receive c0))
  )
  (shield
    (do
      (attack (self) (age))
      (target-shield
        (if
          (< (rotation) (storage))
          (do (photosynthesize) (nearest-corpse))
          (bond c1)
        )
      )
    )
  )
)
```

## Variant 33456: 297 living, 330 births

Harvest 87131.8515625, depth 3.

```lisp
(seq
  (shield (listen c3))
  (photosynthesize)
  (do (photosynthesize) (split))
  (photosynthesize)
  (eat)
  (set m6 (crowding))
)
```

## Variant 33577: 239 living, 276 births

Harvest 109026.61328125, depth 2.

```lisp
(seq
  (unlink (nearest-corpse))
  (give
    (do (photosynthesize) (do (bud) (self)))
    (min (age) (listen c2))
  )
  (photosynthesize)
)
```

## Variant 33342: 157 living, 171 births

Harvest 66498.5, depth 4.

```lisp
(seq
  (shield (listen c0))
  (photosynthesize)
  (do (photosynthesize) (split))
  (photosynthesize)
  (eat)
  (set m6 (crowding))
)
```

## Variant 32007: 146 living, 212 births

Harvest 93749.9609375, depth 2.

```lisp
(seq
  (let ((local5 (state ((state7 (target-distance (nearest-cell))))
      (+ (sunlight-bearing) (generation))
    )))
    (photosynthesize)
  )
  (eat)
  (split)
  (photosynthesize)
  (color-set
    (target-temperature
      (scan
        (storage)
        (state ((state5 (sunlight-slope)))
          (-
            (* (sunlight-bearing) (sunlight))
            (target-color
              (scan-color
                (rotation)
                (sunlight-bearing)
              )
            )
          )
        )
      )
    )
  )
)
```

## Variant 33529: 145 living, 166 births

Harvest 57022.9296875, depth 1.

```lisp
(seq
  (photosynthesize)
  (mobilize (target-tag (do (split) (none))))
  (unlink (bond c0))
  (do
    (photosynthesize)
    (unlink
      (state ((state7 (energy)))
        (nearest-cell)
      )
    )
  )
  (nop)
  (tag-set
    (target-shield
      (scan-color
        (receive c2)
        (storage-bearing (age))
      )
    )
  )
)
```

## Variant 33132: 140 living, 149 births

Harvest 56733.8203125, depth 1.

```lisp
(seq
  (photosynthesize)
  (mobilize (target-tag (do (split) (none))))
  (unlink (bond c1))
  (do
    (photosynthesize)
    (unlink
      (state ((state7 (energy)))
        (nearest-cell)
      )
    )
  )
  (nop)
  (tag-set (sunlight-slope))
)
```

## Variant 32293: 135 living, 153 births

Harvest 67337.08984375, depth 2.

```lisp
(seq
  (let ((local5 (sunlight-bearing)))
    (photosynthesize)
  )
  (eat)
  (split)
  (photosynthesize)
  (color-set
    (target-temperature
      (scan
        (storage)
        (state ((state5 (sunlight-slope)))
          (-
            (min (age) (age))
            (target-color
              (scan-color
                (rotation)
                (sunlight-bearing)
              )
            )
          )
        )
      )
    )
  )
)
```
