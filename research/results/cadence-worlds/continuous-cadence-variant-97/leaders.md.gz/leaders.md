## Variant 17280: 4785 living, 37029 births

Harvest 7968485.17578125, depth 1.

```lisp
(seq
  (do
    (shield (sunlight-slope))
    (do
      (link
        (do
          (eat)
          (let ((local5 (storage)))
            (none)
          )
        )
      )
      (photosynthesize)
    )
  )
  (color-set
    (target-distance
      (scan-color (sunlight) (linked_storage))
    )
  )
  (move (max (target-tag (self)) (generation)))
  (split)
  (nop)
)
```

## Variant 13627: 3197 living, 66000 births

Harvest 16777215.99609375, depth 2.

```lisp
(seq
  (unlink
    (scan-color
      (do (photosynthesize) (energy))
      (max (linked_temperature) (memory m0))
    )
  )
  (move (crowding))
  (bud)
)
```

## Variant 24723: 3092 living, 13176 births

Harvest 2409485.78515625, depth 1.

```lisp
(seq
  (tag-set
    (state ((state4 (* (linked_temperature) (linked_temperature))))
      (target-tag
        (let ((local3 (generation)))
          (bond c2)
        )
      )
    )
  )
  (give
    (if
      (kin (nearest-cell))
      (scan-color
        (linked_storage)
        (storage-slope (age))
      )
      (bond c1)
    )
    (bonds)
  )
  (do (photosynthesize) (bud))
)
```

## Variant 19019: 2024 living, 16435 births

Harvest 3672753.91796875, depth 2.

```lisp
(seq
  (seq
    (move 0.9502708911895752)
    (color-set (receive c2))
  )
  (eat)
  (photosynthesize)
  (let ((local0 (temperature)))
    (set m6 0.5)
  )
  (nop)
  (split)
)
```

## Variant 26573: 1730 living, 9351 births

Harvest 1634422.78125, depth 0.

```lisp
(seq
  (tag-set
    (state ((state4 (* (linked_temperature) (linked_temperature))))
      (target-color (nearest-cell))
    )
  )
  (give
    (if
      (kin (nearest-cell))
      (scan-color
        (linked_storage)
        (storage-slope (age))
      )
      (bond c1)
    )
    (bonds)
  )
  (do (photosynthesize) (bud))
)
```

## Variant 17554: 1475 living, 6984 births

Harvest 3211685.5703125, depth 0.

```lisp
(seq
  (eat)
  (color-set
    (target-energy
      (scan-color (crowding) (sunlight-slope))
    )
  )
  (seq (set m1 0.25) (eat))
  (photosynthesize)
  (if
    true
    (photosynthesize)
    (do (split) (mobilize (linked_temperature)))
  )
  (if true (if true (split) (bud)) (bud))
)
```

## Variant 27024: 796 living, 1278 births

Harvest 229836.703125, depth 1.

```lisp
(seq
  (nop)
  (photosynthesize)
  (do (nop) (tag-set (/ (generation) (tag))))
  (if
    (alive
      (if
        (state ((state6 0.25))
          false
        )
        (nearest-cell)
        (nearest-cell)
      )
    )
    (if
      (alive (nearest-corpse))
      (split)
      (color-set (rotation))
    )
    (nop)
  )
  (split)
)
```

## Variant 20261: 541 living, 16538 births

Harvest 4606396.4140625, depth 0.

```lisp
(seq
  (tag-set
    (state ((state4 (* (linked_temperature) (linked_temperature))))
      (target-color (nearest-cell))
    )
  )
  (give
    (if
      (kin (nearest-cell))
      (scan-color
        (linked_storage)
        (storage-slope (age))
      )
      (bond c1)
    )
    (bonds)
  )
  (do (photosynthesize) (bud))
)
```

## Variant 24062: 495 living, 6733 births

Harvest 1495811.92578125, depth 0.

```lisp
(seq
  (let ((local7 (color)))
    (photosynthesize)
  )
  (seq
    (color-set (bonds))
    (if false (photosynthesize) (eat))
  )
  (store (bonds))
  (split)
)
```

## Variant 32436: 262 living, 298 births

Harvest 32623.015625, depth 1.

```lisp
(seq
  (eat)
  (color-set
    (target-energy
      (scan-color (crowding) (sunlight-slope))
    )
  )
  (seq (set m1 0.25) (eat))
  (photosynthesize)
  (if
    true
    (photosynthesize)
    (do (split) (seq (nop) (split)))
  )
  (if true (if true (split) (bud)) (bud))
)
```

## Variant 23845: 196 living, 1355 births

Harvest 288542.3515625, depth 3.

```lisp
(seq
  (seq
    (move 0.9502708911895752)
    (color-set (receive c2))
  )
  (eat)
  (photosynthesize)
  (let ((local0 (temperature)))
    (set m5 0.5)
  )
  (nop)
  (split)
)
```

## Variant 30365: 193 living, 591 births

Harvest 58727.77734375, depth 1.

```lisp
(seq
  (tag-set 1)
  (give
    (if
      (kin (nearest-cell))
      (scan-color
        (linked_storage)
        (storage-slope (age))
      )
      (bond c1)
    )
    (bonds)
  )
  (do (photosynthesize) (bud))
)
```
