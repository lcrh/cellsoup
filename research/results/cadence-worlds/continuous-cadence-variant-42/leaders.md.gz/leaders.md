## Variant 8717: 4958 living, 26074 births

Harvest 16777215.99609375, depth 0.

```lisp
(seq
  (seq (unlink (self)) (bud))
  (move
    (target-storage
      (state ((state1 (age)))
        (nearest-cell)
      )
    )
  )
  (unlink (if false (self) (nearest-cell)))
  (do
    (seq (eat) (photosynthesize))
    (tag-set (generation))
  )
  (link (nearest-corpse))
)
```

## Variant 9800: 4863 living, 72254 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (move (if (do (split) false) (sunlight) (crowding)))
  (photosynthesize)
  (do
    (unlink (none))
    (state ((state2 (storage)))
      (link (none))
    )
  )
  (send (bond c1) c1 (target-distance (bond c3)))
)
```

## Variant 1653: 1228 living, 23634 births

Harvest 11698540.453125, depth 0.

```lisp
(seq
  (attack (self) (linked_temperature))
  (eat)
  (photosynthesize)
  (move (color))
  (do (split) (move (listen c1)))
)
```

## Variant 22884: 780 living, 850 births

Harvest 400252.484375, depth 1.

```lisp
(seq
  (if (do (photosynthesize) true) (eat) (nop))
  (turn (sunlight-slope))
  (do
    (link (nearest-corpse))
    (state ((state4 (receive c2)))
      (unlink (none))
    )
  )
  (bud)
)
```

## Variant 24585: 531 living, 657 births

Harvest 371665.9609375, depth 3.

```lisp
(seq
  (split)
  (state ((state4 (random (energy))))
    (unlink
      (state ((state4 (sunlight)))
        (if
          (let ((local1 (target-bearing (nearest-cell))))
            (do (eat) true)
          )
          (scan-color (age) (receive c2))
          (nearest-corpse)
        )
      )
    )
  )
  (photosynthesize)
)
```

## Variant 22306: 529 living, 588 births

Harvest 461012.8984375, depth 0.

```lisp
(seq
  (send (nearest-corpse) c0 (bonds))
  (let ((local2 (sunlight)))
    (bud)
  )
  (do (photosynthesize) (unlink (nearest-corpse)))
  (move (target-bearing (nearest-corpse)))
  (move (target-tag (bond c0)))
  (eat)
)
```

## Variant 23754: 498 living, 542 births

Harvest 375755.12109375, depth 3.

```lisp
(seq
  (bud)
  (if
    true
    (state ((state7 (sunlight-bearing)))
      (color-set (storage))
    )
    (color-set (bonds))
  )
  (mobilize (tag))
  (unlink
    (let ((local0 (target-color (bond c2))))
      (let ((local4 (temperature)))
        (let ((local2 (random (crowding))))
          (do (photosynthesize) (nearest-cell))
        )
      )
    )
  )
)
```

## Variant 22540: 494 living, 588 births

Harvest 727163.03515625, depth 4.

```lisp
(seq
  (photosynthesize)
  (if false (photosynthesize) (photosynthesize))
  (unlink (self))
  (if (= (tag) 0) (photosynthesize) (eat))
  (mobilize (energy))
  (unlink
    (scan-color
      (temperature)
      (target-tag (nearest-cell))
    )
  )
  (bud)
)
```

## Variant 24396: 488 living, 542 births

Harvest 355574.96875, depth 2.

```lisp
(seq
  (if (do (photosynthesize) true) (eat) (nop))
  (nop)
  (do
    (link (nearest-corpse))
    (state ((state4 (receive c2)))
      (unlink (none))
    )
  )
  (bud)
)
```

## Variant 21179: 425 living, 831 births

Harvest 518372.8359375, depth 2.

```lisp
(seq
  (state ((state0 (rotation)))
    (unlink (nearest-corpse))
  )
  (let ((local3 (memory m1)))
    (bud)
  )
  (do (photosynthesize) (color-set (listen c1)))
  (let ((local5 (target-bonds (self))))
    (tag-set
      (do
        (seq (photosynthesize) (eat))
        (birth-result)
      )
    )
  )
)
```

## Variant 24808: 423 living, 498 births

Harvest 312377.8046875, depth 2.

```lisp
(seq
  (turn (* (tag) (sunlight-bearing)))
  (mobilize (linked_temperature))
  (do (turn (storage-slope (birth-result))) (split))
  (let ((local7 (storage)))
    (let ((local4 (linked_temperature)))
      (eat)
    )
  )
  (let ((local1 (temperature)))
    (photosynthesize)
  )
)
```

## Variant 22312: 416 living, 454 births

Harvest 396708.39453125, depth 3.

```lisp
(seq
  (tag-set (energy))
  (photosynthesize)
  (do (send (self) c2 (generation)) (split))
  (unlink
    (if
      (< (birth-result) (/ 90 (color)))
      (scan-color (crowding) (temperature))
      (nearest-cell)
    )
  )
)
```
