## Variant 13274: 15961 living, 71263 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (turn (crowding))
  (photosynthesize)
  (state ((state6 (linked_temperature)))
    (seq (split) (eat))
  )
  (nop)
  (seq (photosynthesize) (move (color)))
  (color-set (generation))
)
```

## Variant 16578: 3460 living, 19565 births

Harvest 12000501.359375, depth 2.

```lisp
(seq
  (do (photosynthesize) (split))
  (photosynthesize)
  (eat)
  (bud)
  (move (sunlight-bearing))
  (photosynthesize)
)
```

## Variant 23275: 2074 living, 2960 births

Harvest 2207084.33203125, depth 2.

```lisp
(seq
  (do (photosynthesize) (seq (nop) (nop) (split)))
  (move (/ (storage) (max (age) (memory m5))))
  (photosynthesize)
  (state ((state6 (listen c2)))
    (if
      (and true (> (sunlight-slope) (tag)))
      (eat)
      (set m2 (birth-result))
    )
  )
)
```

## Variant 19541: 772 living, 2508 births

Harvest 1318682.01953125, depth 2.

```lisp
(seq
  (photosynthesize)
  (eat)
  (state ((state4 (memory m5)))
    (turn
      (storage-bearing
        (target-energy
          (do (move (temperature)) (self))
        )
      )
    )
  )
  (split)
  (photosynthesize)
)
```

## Variant 11769: 604 living, 1585 births

Harvest 1179995.37109375, depth 0.

```lisp
(seq
  (turn (crowding))
  (photosynthesize)
  (state ((state6 (linked_temperature)))
    (seq (split) (eat))
  )
  (nop)
  (seq
    (photosynthesize)
    (move
      (do (link (self)) (target-bonds (nearest-cell)))
    )
  )
  (color-set (generation))
)
```

## Variant 14633: 545 living, 927 births

Harvest 492205.41796875, depth 1.

```lisp
(seq
  (nop)
  (photosynthesize)
  (state ((state6 (linked_temperature)))
    (seq (split) (eat))
  )
  (nop)
  (seq
    (photosynthesize)
    (move
      (do (link (self)) (target-bonds (nearest-cell)))
    )
  )
  (color-set (generation))
)
```

## Variant 27141: 499 living, 525 births

Harvest 437122.0625, depth 0.

```lisp
(seq
  (send (nearest-corpse) c0 (birth-result))
  (seq (photosynthesize) (nop))
  (do (set m7 (tag)) (eat))
  (seq
    (split)
    (do
      (attack (bond c2) (random (crowding)))
      (photosynthesize)
    )
  )
  (color-set (memory m6))
)
```

## Variant 20013: 462 living, 2475 births

Harvest 1812536.48828125, depth 2.

```lisp
(seq
  (do (photosynthesize) (seq (nop) (nop) (split)))
  (move (/ (storage) (max (age) (memory m5))))
  (photosynthesize)
  (state ((state6 (listen c2)))
    (if
      (and true (> (sunlight-slope) (tag)))
      (eat)
      (set m2 (birth-result))
    )
  )
)
```

## Variant 20246: 391 living, 1273 births

Harvest 965223.546875, depth 0.

```lisp
(seq
  (seq (eat) (store (receive c3)))
  (photosynthesize)
  (unlink (nearest-corpse))
  (bud)
  (photosynthesize)
)
```

## Variant 15232: 330 living, 1556 births

Harvest 902748.0234375, depth 1.

```lisp
(seq
  (turn (crowding))
  (photosynthesize)
  (seq (split) (eat))
  (nop)
  (seq (photosynthesize) (move (temperature)))
  (color-set (generation))
)
```

## Variant 15194: 291 living, 674 births

Harvest 434397.35546875, depth 2.

```lisp
(seq
  (state ((state6 (listen c1)))
    (do (photosynthesize) (split))
  )
  (if
    (< (temperature) (tag))
    (bud)
    (color-set (rotation))
  )
  (eat)
  (let ((local5 (target-bearing (bond c1))))
    (photosynthesize)
  )
)
```

## Variant 26800: 249 living, 261 births

Harvest 209728.6640625, depth 0.

```lisp
(seq
  (seq (eat) (store (receive c3)))
  (photosynthesize)
  (unlink (nearest-corpse))
  (bud)
  (photosynthesize)
)
```
