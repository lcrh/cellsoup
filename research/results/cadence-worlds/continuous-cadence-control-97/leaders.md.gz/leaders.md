## Variant 30935: 9164 living, 41075 births

Harvest 2528516.91015625, depth 5.

```lisp
(seq
  (state ((state5 (generation)))
    (photosynthesize)
  )
  (bud)
  (if
    (and
      (not (if (kin (none)) true false))
      (not (kin (nearest-cell)))
    )
    (mobilize (crowding))
    (give (nearest-cell) (crowding))
  )
  (do
    (move (target-color (none)))
    (unlink (nearest-corpse))
  )
  (photosynthesize)
)
```

## Variant 24560: 4946 living, 12632 births

Harvest 4083556.81640625, depth 3.

```lisp
(seq
  (set m2 (target-bearing (bond c3)))
  (move (crowding))
  (photosynthesize)
  (seq
    (do (eat) (send (nearest-corpse) c0 (crowding)))
    (split)
  )
  (photosynthesize)
)
```

## Variant 11720: 3726 living, 56029 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (if true (photosynthesize) (nop))
  (move (color))
  (attack (nearest-corpse) (sunlight-slope))
  (nop)
  (unlink
    (do
      (eat)
      (state ((state6 (tag)))
        (nearest-cell)
      )
    )
  )
  (split)
  (photosynthesize)
)
```

## Variant 30100: 2445 living, 5169 births

Harvest 330734.484375, depth 4.

```lisp
(seq
  (state ((state5 (generation)))
    (photosynthesize)
  )
  (bud)
  (if
    (and
      (not (if (kin (none)) true false))
      (not (kin (nearest-cell)))
    )
    (mobilize (crowding))
    (give (nearest-cell) (crowding))
  )
  (do
    (move (target-tag (none)))
    (unlink (nearest-corpse))
  )
  (photosynthesize)
)
```

## Variant 24755: 2089 living, 6959 births

Harvest 2422210.953125, depth 3.

```lisp
(seq
  (let ((local3 2))
    (move (target-color (none)))
  )
  (move (crowding))
  (photosynthesize)
  (seq
    (state ((state5 (sunlight)))
      (turn (memory m2))
    )
    (split)
  )
  (photosynthesize)
)
```

## Variant 17764: 1677 living, 14417 births

Harvest 6573566.5234375, depth 1.

```lisp
(seq
  (eat)
  (photosynthesize)
  (move (sunlight-bearing))
  (split)
  (photosynthesize)
)
```

## Variant 23855: 1447 living, 24813 births

Harvest 3124386.81640625, depth 3.

```lisp
(seq
  (state ((state5 (generation)))
    (photosynthesize)
  )
  (bud)
  (if
    (and
      (not (if (kin (none)) true false))
      (not (kin (nearest-cell)))
    )
    (tag-set (linked_temperature))
    (give (nearest-cell) (crowding))
  )
  (turn (abs (* (memory m6) (linked_storage))))
  (photosynthesize)
)
```

## Variant 30316: 1416 living, 15772 births

Harvest 924315.89453125, depth 4.

```lisp
(seq
  (state ((state5 (generation)))
    (photosynthesize)
  )
  (bud)
  (if
    (and
      (not (if (kin (none)) true false))
      (not (kin (nearest-cell)))
    )
    (mobilize (crowding))
    (give (nearest-cell) (crowding))
  )
  (do
    (move (target-tag (none)))
    (unlink (nearest-corpse))
  )
  (photosynthesize)
)
```

## Variant 16254: 803 living, 2336 births

Harvest 606001.03515625, depth 2.

```lisp
(seq
  (if true (photosynthesize) (nop))
  (move (min (birth-result) (storage)))
  (attack (nearest-corpse) (sunlight-slope))
  (nop)
  (unlink
    (do
      (eat)
      (state ((state6 (tag)))
        (nearest-cell)
      )
    )
  )
  (split)
  (photosynthesize)
)
```

## Variant 16567: 609 living, 37412 births

Harvest 12485142.28125, depth 2.

```lisp
(seq
  (set m2 (target-bearing (bond c3)))
  (move (crowding))
  (photosynthesize)
  (seq
    (state ((state5 (sunlight)))
      (turn (memory m2))
    )
    (split)
  )
  (photosynthesize)
)
```

## Variant 23559: 520 living, 53401 births

Harvest 5532356.75390625, depth 3.

```lisp
(seq
  (state ((state5 (generation)))
    (photosynthesize)
  )
  (bud)
  (if
    (and
      (not (if (kin (none)) true false))
      (not (kin (nearest-cell)))
    )
    (mobilize (crowding))
    (give (nearest-cell) (crowding))
  )
  (turn (receive c0))
  (photosynthesize)
)
```

## Variant 21872: 396 living, 7416 births

Harvest 957269.23046875, depth 2.

```lisp
(seq
  (state ((state5 (generation)))
    (photosynthesize)
  )
  (bud)
  (if
    (and
      (not (if (kin (none)) true false))
      (not (kin (nearest-cell)))
    )
    (mobilize (crowding))
    (give (nearest-cell) (crowding))
  )
  (give (self) (receive c1))
  (photosynthesize)
)
```
