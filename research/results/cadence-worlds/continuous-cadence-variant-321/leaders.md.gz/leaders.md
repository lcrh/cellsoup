## Variant 63: 25093 living, 281998 births

Harvest 16777215.99609375, depth 0.

```lisp
(seq
  (link (nearest-corpse))
  (give (bond c2) (target-energy (nearest-cell)))
  (seq (eat) (photosynthesize))
  (eat)
  (set
    m1
    (target-bearing
      (scan-color
        (max 0 (birth-result))
        (birth-result)
      )
    )
  )
  (bud)
)
```

## Variant 6608: 3977 living, 10928 births

Harvest 5850732.203125, depth 0.

```lisp
(seq
  (nop)
  (color-set (target-shield (nearest-cell)))
  (state ((state3 (target-bonds (none))))
    (photosynthesize)
  )
  (eat)
  (move (energy))
  (do
    (if false (photosynthesize) (bud))
    (let ((local1 (storage-slope (sunlight-bearing))))
      (if false (photosynthesize) (set m0 5))
    )
  )
)
```

## Variant 20301: 1654 living, 4099 births

Harvest 1035962.98828125, depth 1.

```lisp
(seq
  (link (nearest-corpse))
  (give (bond c1) (target-energy (nearest-cell)))
  (seq (eat) (photosynthesize))
  (eat)
  (set
    m1
    (target-bearing
      (scan-color
        (max 0 (birth-result))
        (birth-result)
      )
    )
  )
  (bud)
)
```

## Variant 19816: 574 living, 753 births

Harvest 322532.3359375, depth 1.

```lisp
(seq
  (nop)
  (color-set (target-shield (nearest-cell)))
  (state ((state3 (target-bonds (nearest-corpse))))
    (photosynthesize)
  )
  (eat)
  (move (energy))
  (do
    (if false (photosynthesize) (bud))
    (let ((local1 (storage-slope (sunlight-bearing))))
      (if false (photosynthesize) (set m0 5))
    )
  )
)
```

## Variant 9343: 142 living, 548 births

Harvest 257721.3828125, depth 1.

```lisp
(seq
  (move (storage-slope (sunlight-bearing)))
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local5 (target-tag (none))))
      (storage-slope (memory m2))
    )
  )
)
```

## Variant 4947: 84 living, 8272 births

Harvest 4287220.15625, depth 0.

```lisp
(seq
  (move (abs (sunlight-slope)))
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local5 (target-tag (none))))
      (storage-slope local5)
    )
  )
)
```

## Variant 21314: 81 living, 131 births

Harvest 65009.89453125, depth 2.

```lisp
(seq
  (attack (none) (target-shield (nearest-corpse)))
  (seq (eat) (photosynthesize))
  (photosynthesize)
  (split)
  (color-set (birth-result))
  (color-set (crowding))
)
```

## Variant 21212: 53 living, 73 births

Harvest 31520.57421875, depth 3.

```lisp
(seq
  (mobilize (crowding))
  (eat)
  (tag-set (storage-slope (storage-slope (color))))
  (give
    (do (photosynthesize) (nearest-cell))
    (mod
      (target-bearing
        (state ((state4 (rotation)))
          (if
            false
            (let ((local1 (generation)))
              (self)
            )
            (bond c0)
          )
        )
      )
      (storage)
    )
  )
  (split)
)
```

## Variant 21516: 45 living, 69 births

Harvest 25437.16796875, depth 0.

```lisp
(seq
  (split)
  (let ((local7 (abs
      (target-energy
        (scan-color (sunlight) (linked_temperature))
      )
    )))
    (let ((local1 (do (tag-set (rotation)) 10)))
      (photosynthesize)
    )
  )
  (state ((state6 (target-storage (none))))
    (nop)
  )
)
```

## Variant 21170: 43 living, 109 births

Harvest 41632.69140625, depth 4.

```lisp
(seq
  (state ((state3 (listen c1)))
    (do (photosynthesize) (split))
  )
  (if
    (< (temperature) (tag))
    (bud)
    (color-set (rotation))
  )
  (eat)
  (let ((local5 (target-bearing (bond c3))))
    (photosynthesize)
  )
)
```

## Variant 21725: 25 living, 31 births

Harvest 12796.3828125, depth 3.

```lisp
(seq
  (attack (none) (target-color (nearest-cell)))
  (mobilize (color))
  (state ((state3 (listen c1)))
    (do (photosynthesize) (split))
  )
)
```

## Variant 21699: 25 living, 24 births

Harvest 5396.6640625, depth 2.

```lisp
(seq
  (do
    (turn (storage-slope (receive c3)))
    (mobilize (bonds))
  )
  (photosynthesize)
  (attack
    (let ((local1 (storage)))
      (none)
    )
    (target-bearing (self))
  )
  (let ((local1 (storage)))
    (state ((state0 (linked_temperature)))
      (let ((local2 (target-shield (nearest-cell))))
        (split)
      )
    )
  )
)
```
