## Variant 22562: 13572 living, 82329 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (photosynthesize)
  (bud)
  (give (bond c3) 10)
  (eat)
  (move (age))
  (tag-set (tag))
  (eat)
  (move (target-energy (do (photosynthesize) (self))))
)
```

## Variant 24990: 250 living, 1113 births

Harvest 380810.625, depth 2.

```lisp
(seq
  (photosynthesize)
  (bud)
  (give (bond c3) 10)
  (attack
    (scan-color (bonds) (linked_storage))
    (target-storage (nearest-corpse))
  )
  (move (age))
  (tag-set (tag))
  (eat)
  (move (target-energy (do (photosynthesize) (self))))
)
```

## Variant 27843: 99 living, 203 births

Harvest 70315.14453125, depth 4.

```lisp
(seq
  (state ((state6 (sunlight-bearing)))
    (eat)
  )
  (unlink
    (scan (age) (target-storage (nearest-corpse)))
  )
  (photosynthesize)
  (bud)
  (photosynthesize)
)
```

## Variant 27823: 93 living, 177 births

Harvest 75987.76171875, depth 4.

```lisp
(seq
  (photosynthesize)
  (split)
  (seq
    (if
      (let ((local5 (temperature)))
        (and
          (< (crowding) (target-tag (nearest-corpse)))
          (state ((state2 3))
            (not (= (birth-result) (crowding)))
          )
        )
      )
      (nop)
      (nop)
    )
    (move (tag))
  )
  (eat)
  (photosynthesize)
)
```

## Variant 22683: 49 living, 89 births

Harvest 26030.24609375, depth 3.

```lisp
(seq
  (move (receive c3))
  (photosynthesize)
  (seq
    (split)
    (seq (if true (nop) (nop)) (move (tag)))
    (eat)
    (photosynthesize)
  )
  (eat)
  (give (none) (if (not true) (crowding) (bonds)))
  (photosynthesize)
)
```

## Variant 29455: 43 living, 77 births

Harvest 34997.45703125, depth 3.

```lisp
(seq
  (tag-set (/ (sunlight) (generation)))
  (tag-set (target-bearing (nearest-cell)))
  (do (photosynthesize) (split))
  (mobilize (tag))
  (unlink (none))
  (photosynthesize)
)
```

## Variant 28047: 41 living, 88 births

Harvest 30325.98046875, depth 4.

```lisp
(seq
  (photosynthesize)
  (split)
  (seq
    (if
      (let ((local5 (temperature)))
        (and
          (< (crowding) (target-tag (bond c2)))
          (state ((state2 3))
            (not (= (birth-result) (crowding)))
          )
        )
      )
      (nop)
      (nop)
    )
    (move (tag))
  )
  (eat)
  (photosynthesize)
)
```

## Variant 25216: 37 living, 70 births

Harvest 25084.609375, depth 2.

```lisp
(seq
  (photosynthesize)
  (split)
  (seq
    (if
      (let ((local5 (temperature)))
        (and
          (<
            (crowding)
            (target-tag (if false (none) (none)))
          )
          (state ((state2 3))
            (kin (nearest-cell))
          )
        )
      )
      (nop)
      (nop)
    )
    (move (tag))
  )
  (eat)
  (photosynthesize)
)
```

## Variant 27963: 33 living, 49 births

Harvest 20565.125, depth 3.

```lisp
(seq
  (tag-set
    (let ((local4 (energy)))
      (bonds)
    )
  )
  (unlink
    (scan (age) (target-storage (nearest-corpse)))
  )
  (photosynthesize)
  (bud)
  (photosynthesize)
)
```

## Variant 30357: 32 living, 44 births

Harvest 11821.95703125, depth 4.

```lisp
(seq
  (state ((state6 (sunlight-bearing)))
    (eat)
  )
  (unlink
    (scan (age) (target-storage (nearest-corpse)))
  )
  (photosynthesize)
  (bud)
  (photosynthesize)
)
```

## Variant 17806: 25 living, 630 births

Harvest 204740.890625, depth 3.

```lisp
(seq
  (let ((local2 (age)))
    (photosynthesize)
  )
  (split)
  (eat)
  (give
    (nearest-cell)
    (storage-bearing (sunlight-bearing))
  )
  (give
    (nearest-cell)
    (*
      (*
        (storage-slope (/ (linked_storage) 90))
        (storage)
      )
      (target-shield
        (let ((local3 (abs (target-storage (none)))))
          (none)
        )
      )
    )
  )
  (photosynthesize)
)
```

## Variant 27462: 22 living, 72 births

Harvest 38885.375, depth 2.

```lisp
(seq
  (seq (photosynthesize) (photosynthesize))
  (split)
  (photosynthesize)
  (shield (memory m3))
  (mobilize (birth-result))
  (photosynthesize)
)
```
