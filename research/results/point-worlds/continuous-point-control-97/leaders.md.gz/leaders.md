## Variant 16633: 21626 living, 220311 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (give (bond c2) (bonds))
  (photosynthesize)
  (do
    (state ((state0 (rotation)))
      (bud)
    )
    (photosynthesize)
  )
)
```

## Variant 14973: 6145 living, 117548 births

Harvest 16777215.99609375, depth 0.

```lisp
(seq
  (give (bond c2) (bonds))
  (photosynthesize)
  (do
    (state ((state0 (temperature)))
      (bud)
    )
    (photosynthesize)
  )
)
```

## Variant 16296: 2406 living, 24384 births

Harvest 7589589.58203125, depth 3.

```lisp
(seq
  (give (self) (generation))
  (give (nearest-corpse) (crowding))
  (photosynthesize)
  (do
    (seq (turn (storage-bearing (bonds))) (eat))
    (bud)
  )
  (color-set (* (min (age) (sunlight-bearing)) 360))
  (photosynthesize)
  (move
    (let ((local0 (generation)))
      (temperature)
    )
  )
)
```

## Variant 13790: 393 living, 14243 births

Harvest 7074628.6328125, depth 1.

```lisp
(seq
  (eat)
  (photosynthesize)
  (seq
    (bud)
    (move (- (age) (crowding)))
    (photosynthesize)
    (do (eat) (tag-set (linked_storage)))
  )
  (split)
  (photosynthesize)
)
```

## Variant 19983: 210 living, 2728 births

Harvest 719500.83203125, depth 4.

```lisp
(seq
  (give (self) (linked_storage))
  (give (nearest-corpse) (crowding))
  (photosynthesize)
  (do
    (seq (turn (storage-bearing (bonds))) (eat))
    (bud)
  )
  (color-set (* (min (age) (sunlight-bearing)) 360))
  (photosynthesize)
  (move
    (let ((local0 (generation)))
      (temperature)
    )
  )
)
```

## Variant 23160: 54 living, 105 births

Harvest 39158.64453125, depth 1.

```lisp
(seq
  (give (bond c2) (bonds))
  (photosynthesize)
  (turn (linked_storage))
  (eat)
  (photosynthesize)
  (send
    (scan (temperature) (linked_temperature))
    c0
    (target-bearing (self))
  )
  (split)
  (photosynthesize)
)
```

## Variant 22918: 30 living, 120 births

Harvest 23373.19921875, depth 4.

```lisp
(seq
  (give (self) (generation))
  (give (nearest-corpse) (crowding))
  (photosynthesize)
  (do
    (seq (turn (storage-bearing (energy))) (eat))
    (bud)
  )
  (color-set (* (min (age) (sunlight-bearing)) 360))
  (photosynthesize)
  (move
    (let ((local0 (generation)))
      (temperature)
    )
  )
)
```

## Variant 26669: 27 living, 26 births

Harvest 5712.80859375, depth 4.

```lisp
(seq
  (eat)
  (photosynthesize)
  (move
    (storage-slope
      (-
        (sunlight-slope)
        (target-bearing (nearest-cell))
      )
    )
  )
  (bud)
  (photosynthesize)
  (do (eat) (tag-set (linked_storage)))
)
```

## Variant 21286: 20 living, 71 births

Harvest 52121.4921875, depth 3.

```lisp
(seq
  (link (self))
  (photosynthesize)
  (move
    (storage-slope
      (-
        (sunlight-slope)
        (target-bearing
          (if true (nearest-corpse) (nearest-corpse))
        )
      )
    )
  )
  (bud)
  (photosynthesize)
  (do (eat) (tag-set (linked_storage)))
)
```

## Variant 23495: 19 living, 54 births

Harvest 36163.59375, depth 4.

```lisp
(seq
  (eat)
  (seq (unlink (nearest-corpse)) (photosynthesize))
  (mobilize (target-color (scan-color 2 (crowding))))
  (split)
  (photosynthesize)
)
```

## Variant 15971: 19 living, 250 births

Harvest 66687.66015625, depth 2.

```lisp
(seq
  (send
    (none)
    c3
    (if
      (kin
        (let ((local5 (storage)))
          (self)
        )
      )
      (energy)
      (linked_storage)
    )
  )
  (move (energy))
  (eat)
  (photosynthesize)
  (send
    (scan (temperature) (target-bonds (none)))
    c1
    (target-bearing (self))
  )
  (split)
  (photosynthesize)
)
```

## Variant 26664: 17 living, 18 births

Harvest 6468.90234375, depth 5.

```lisp
(seq
  (if true (photosynthesize) (shield (generation)))
  (color-set (+ (temperature) 25))
  (store (random (birth-result)))
  (bud)
  (let ((local1 (do (eat) (storage))))
    (seq
      (mobilize (target-bonds (bond c1)))
      (do (photosynthesize) (nop))
    )
  )
)
```
