## Variant 11119: 16374 living, 109699 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (turn (crowding))
  (photosynthesize)
  (state ((state6 (linked_temperature)))
    (seq (split) (eat))
  )
  (nop)
  (seq
    (photosynthesize)
    (move (do (link (self)) 120))
  )
  (color-set (generation))
)
```

## Variant 15877: 3632 living, 17558 births

Harvest 8458241.15625, depth 3.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (link (bond c2))
  (turn
    (storage-bearing
      (target-energy
        (do
          (move (temperature))
          (scan-color (sunlight-slope) (color))
        )
      )
    )
  )
)
```

## Variant 14947: 729 living, 1724 births

Harvest 1227714.71875, depth 2.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local7 (target-tag (none))))
      (storage-slope (memory m5))
    )
  )
)
```

## Variant 12915: 657 living, 4030 births

Harvest 2198728.015625, depth 2.

```lisp
(seq
  (turn (crowding))
  (photosynthesize)
  (state ((state6 (linked_temperature)))
    (seq (split) (eat))
  )
  (nop)
  (seq
    (photosynthesize)
    (move (do (link (self)) 120))
  )
  (color-set
    (mod
      (bonds)
      (target-temperature (scan (bonds) (listen c2)))
    )
  )
)
```

## Variant 27136: 607 living, 612 births

Harvest 503922.078125, depth 2.

```lisp
(seq
  (eat)
  (seq (photosynthesize) (nop))
  (photosynthesize)
  (let ((local5 (rotation)))
    (do (split) (photosynthesize))
  )
  (unlink
    (let ((local1 (tag)))
      (none)
    )
  )
  (state ((state4 (do (wait (energy)) (tag))))
    (turn (storage-bearing (sunlight-slope)))
  )
)
```

## Variant 19193: 522 living, 962 births

Harvest 560180.1875, depth 1.

```lisp
(seq
  (photosynthesize)
  (nop)
  (let ((local1 (target-storage (nearest-corpse))))
    (eat)
  )
  (split)
  (link
    (let ((local5 (sunlight)))
      (self)
    )
  )
  (photosynthesize)
)
```

## Variant 12225: 515 living, 6769 births

Harvest 5251627.77734375, depth 2.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (give (none) (bonds))
)
```

## Variant 26928: 424 living, 462 births

Harvest 354777.19921875, depth 1.

```lisp
(seq
  (shield
    (target-distance (do (photosynthesize) (none)))
  )
  (if
    (do (split) (> 5 (birth-result)))
    (eat)
    (set m4 (generation))
  )
  (attack
    (state ((state6 (bonds)))
      (do (photosynthesize) (self))
    )
    (generation)
  )
  (turn (generation))
)
```

## Variant 12161: 412 living, 1644 births

Harvest 1335363.84765625, depth 1.

```lisp
(seq
  (photosynthesize)
  (link (nearest-corpse))
  (do (do (eat) (nop)) (eat))
  (seq
    (split)
    (do
      (attack (bond c1) (random (crowding)))
      (photosynthesize)
    )
  )
  (color-set (memory m6))
)
```

## Variant 14851: 381 living, 1601 births

Harvest 1026399.734375, depth 1.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local5 (target-tag (none))))
      (storage-slope local5)
    )
  )
)
```

## Variant 12722: 367 living, 2899 births

Harvest 1673884.69140625, depth 1.

```lisp
(seq
  (photosynthesize)
  (split)
  (move (storage))
  (eat)
  (photosynthesize)
  (give
    (none)
    (let ((local5 (target-tag (none))))
      (storage-slope local5)
    )
  )
)
```

## Variant 26541: 361 living, 381 births

Harvest 273985.2734375, depth 4.

```lisp
(seq
  (if false (photosynthesize) (photosynthesize))
  (eat)
  (tag-set (age))
  (tag-set
    (target-tag (do (photosynthesize) (nearest-cell)))
  )
  (shield (target-color (none)))
  (split)
  (state ((state2 (crowding)))
    (photosynthesize)
  )
)
```
