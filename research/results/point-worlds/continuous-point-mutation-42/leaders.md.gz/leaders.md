## Variant 20906: 6449 living, 11866 births

Harvest 7552414.7578125, depth 3.

```lisp
(seq
  (seq (photosynthesize) (bud))
  (move
    (target-storage
      (state ((state1 (age)))
        (nearest-cell)
      )
    )
  )
  (unlink (if false (nearest-corpse) (nearest-cell)))
  (do
    (seq (eat) (photosynthesize))
    (tag-set (generation))
  )
  (link (none))
)
```

## Variant 8722: 5635 living, 62739 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (mobilize (target-temperature (do (eat) (self))))
  (seq
    (unlink (if false (self) (nearest-cell)))
    (do
      (seq (eat) (photosynthesize))
      (tag-set (generation))
    )
    (link (nearest-corpse))
  )
  (bud)
  (move (storage-bearing (bonds)))
  (photosynthesize)
)
```

## Variant 24868: 803 living, 906 births

Harvest 384361.67578125, depth 4.

```lisp
(seq
  (seq (photosynthesize) (bud))
  (move
    (target-storage
      (state ((state1 (age)))
        (nearest-cell)
      )
    )
  )
  (unlink
    (let ((local0 (+ (linked_temperature) (tag))))
      (scan-color
        (sunlight-bearing)
        (target-energy (nearest-corpse))
      )
    )
  )
  (seq (eat) (photosynthesize))
  (link (nearest-corpse))
)
```

## Variant 13102: 629 living, 4054 births

Harvest 2376172.44140625, depth 1.

```lisp
(seq
  (mobilize (target-temperature (do (eat) (self))))
  (seq
    (unlink (if false (self) (nearest-cell)))
    (do
      (seq (eat) (photosynthesize))
      (tag-set (generation))
    )
    (link (nearest-corpse))
  )
  (bud)
  (move (storage-bearing (bonds)))
  (photosynthesize)
)
```

## Variant 14537: 518 living, 2482 births

Harvest 1625209.484375, depth 2.

```lisp
(seq
  (mobilize (target-temperature (do (eat) (self))))
  (seq
    (unlink
      (if
        false
        (let ((local4 (energy)))
          (none)
        )
        (nearest-cell)
      )
    )
    (do
      (seq (eat) (photosynthesize))
      (tag-set (generation))
    )
    (link (nearest-corpse))
  )
  (bud)
  (move (storage-bearing (bonds)))
  (photosynthesize)
)
```

## Variant 27483: 499 living, 570 births

Harvest 313209.94921875, depth 2.

```lisp
(seq
  (tag-set (target-distance (bond c1)))
  (state ((state3 (birth-result)))
    (photosynthesize)
  )
  (photosynthesize)
  (split)
  (photosynthesize)
  (state ((state0 (target-tag
      (scan-color (crowding) (linked_temperature))
    )))
    (tag-set
      (target-energy
        (let ((local1 (color)))
          (self)
        )
      )
    )
  )
)
```

## Variant 24725: 390 living, 1195 births

Harvest 828928.21484375, depth 4.

```lisp
(seq
  (seq (photosynthesize) (bud))
  (move
    (target-storage
      (state ((state1 (age)))
        (nearest-cell)
      )
    )
  )
  (unlink (if false (nearest-cell) (nearest-cell)))
  (seq (eat) (photosynthesize))
  (link (nearest-corpse))
)
```

## Variant 26344: 376 living, 1164 births

Harvest 575018.4140625, depth 3.

```lisp
(seq
  (do
    (seq
      (link
        (if
          (state ((state3 (age)))
            false
          )
          (state ((state2 (target-energy
              (scan-color (color) (generation))
            )))
            (nearest-corpse)
          )
          (do (eat) (nearest-corpse))
        )
      )
      (photosynthesize)
    )
    (move (target-storage (self)))
  )
  (state ((state7 (receive c0)))
    (split)
  )
  (photosynthesize)
)
```

## Variant 22701: 372 living, 1677 births

Harvest 847009.671875, depth 3.

```lisp
(seq
  (seq (photosynthesize) (bud))
  (move
    (target-storage
      (state ((state1 (age)))
        (nearest-cell)
      )
    )
  )
  (move (color))
  (do
    (seq (eat) (photosynthesize))
    (tag-set (generation))
  )
  (unlink (nearest-corpse))
)
```

## Variant 26160: 369 living, 483 births

Harvest 339758.79296875, depth 3.

```lisp
(seq
  (do
    (seq
      (link
        (if
          (state ((state2 (age)))
            false
          )
          (scan (storage) 0.5)
          (do (eat) (nearest-corpse))
        )
      )
      (photosynthesize)
    )
    (move (target-storage (self)))
  )
  (state ((state7 (sunlight)))
    (split)
  )
  (photosynthesize)
)
```

## Variant 27265: 342 living, 359 births

Harvest 215235.1171875, depth 2.

```lisp
(seq
  (store (linked_storage))
  (unlink (none))
  (photosynthesize)
  (bud)
  (photosynthesize)
)
```

## Variant 22827: 341 living, 3259 births

Harvest 1785444.10546875, depth 2.

```lisp
(seq
  (give (bond c3) 10)
  (nop)
  (move (sunlight-bearing))
  (tag-set (storage-slope (target-bonds (bond c2))))
  (photosynthesize)
  (split)
  (seq (eat) (move (tag)))
  (eat)
  (photosynthesize)
)
```
