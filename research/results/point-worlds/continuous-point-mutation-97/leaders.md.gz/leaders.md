## Variant 12820: 2597 living, 18544 births

Harvest 5857378.84375, depth 1.

```lisp
(seq
  (state ((state4 (rotation)))
    (do
      (photosynthesize)
      (do
        (if false (photosynthesize) (nop))
        (send (self) c3 (crowding))
      )
    )
  )
  (seq
    (do (eat) (photosynthesize))
    (move (birth-result))
  )
  (mobilize (target-color (scan-color 2 (crowding))))
  (split)
  (photosynthesize)
)
```

## Variant 14980: 2171 living, 4381 births

Harvest 1487990.62890625, depth 0.

```lisp
(seq
  (eat)
  (photosynthesize)
  (move (sunlight-bearing))
  (split)
  (photosynthesize)
)
```

## Variant 11116: 1956 living, 40149 births

Harvest 13478174.4765625, depth 0.

```lisp
(seq
  (state ((state4 (rotation)))
    (eat)
  )
  (seq
    (do (eat) (photosynthesize))
    (move (birth-result))
  )
  (mobilize (target-color (scan-color 2 (crowding))))
  (split)
  (photosynthesize)
)
```

## Variant 13900: 783 living, 1515 births

Harvest 406627.58203125, depth 0.

```lisp
(seq
  (state ((state4 (rotation)))
    (eat)
  )
  (seq
    (do (eat) (photosynthesize))
    (move (birth-result))
  )
  (mobilize (target-color (scan-color 2 (crowding))))
  (split)
  (photosynthesize)
)
```

## Variant 11596: 494 living, 14955 births

Harvest 5451668.67578125, depth 1.

```lisp
(seq
  (state ((state4 (rotation)))
    (eat)
  )
  (seq (photosynthesize) (move (birth-result)))
  (mobilize
    (target-color (scan-color 2 (linked_storage)))
  )
  (split)
  (photosynthesize)
)
```

## Variant 18346: 459 living, 795 births

Harvest 209242.58984375, depth 1.

```lisp
(seq
  (state ((state4 (rotation)))
    (eat)
  )
  (seq
    (do
      (eat)
      (color-set
        (mod
          (crowding)
          (target-energy
            (let ((local4 (target-bearing (nearest-corpse))))
              (do (photosynthesize) (none))
            )
          )
        )
      )
    )
    (move (birth-result))
  )
  (mobilize (target-color (scan-color 2 (crowding))))
  (split)
  (photosynthesize)
)
```

## Variant 12636: 407 living, 13818 births

Harvest 4776717.9375, depth 0.

```lisp
(seq
  (state ((state4 (rotation)))
    (eat)
  )
  (seq
    (do (eat) (photosynthesize))
    (move (birth-result))
  )
  (mobilize (target-color (scan-color 2 (crowding))))
  (split)
  (photosynthesize)
)
```

## Variant 13285: 294 living, 3259 births

Harvest 1930549.453125, depth 1.

```lisp
(seq
  (state ((state4 (rotation)))
    (eat)
  )
  (seq
    (do (eat) (photosynthesize))
    (tag-set (birth-result))
  )
  (mobilize (target-color (scan-color 2 (crowding))))
  (split)
  (photosynthesize)
)
```

## Variant 15177: 251 living, 3279 births

Harvest 973118.484375, depth 0.

```lisp
(seq
  (state ((state4 (rotation)))
    (eat)
  )
  (seq
    (do (eat) (photosynthesize))
    (move (birth-result))
  )
  (mobilize (target-color (scan-color 2 (crowding))))
  (split)
  (photosynthesize)
)
```

## Variant 14746: 240 living, 747 births

Harvest 246306.671875, depth 1.

```lisp
(seq
  (state ((state4 (rotation)))
    (eat)
  )
  (seq
    (do (eat) (photosynthesize))
    (move (birth-result))
  )
  (mobilize (linked_temperature))
  (split)
  (photosynthesize)
)
```

## Variant 17538: 155 living, 1135 births

Harvest 405889.9140625, depth 1.

```lisp
(seq
  (let ((local4 (rotation)))
    (eat)
  )
  (seq
    (do (eat) (photosynthesize))
    (move (birth-result))
  )
  (mobilize (target-color (scan-color 2 (crowding))))
  (split)
  (photosynthesize)
)
```

## Variant 12496: 134 living, 724 births

Harvest 230411.328125, depth 1.

```lisp
(seq
  (state ((state4 (rotation)))
    (photosynthesize)
  )
  (seq
    (do (eat) (photosynthesize))
    (move (birth-result))
  )
  (mobilize (target-color (scan-color 2 (crowding))))
  (split)
  (photosynthesize)
)
```
