## Variant 13301: 16134 living, 102209 births

Harvest 16777215.99609375, depth 1.

```lisp
(seq
  (turn (crowding))
  (photosynthesize)
  (state ((state6 (linked_temperature)))
    (seq (split) (eat))
  )
  (nop)
  (seq (photosynthesize) (move (age)))
  (color-set (generation))
)
```

## Variant 14274: 1924 living, 12431 births

Harvest 6805278.609375, depth 1.

```lisp
(seq
  (turn (crowding))
  (photosynthesize)
  (state ((state6 (linked_temperature)))
    (seq (split) (eat))
  )
  (nop)
  (seq (photosynthesize) (move (age)))
  (color-set (generation))
)
```

## Variant 14385: 1594 living, 6585 births

Harvest 3404897.9296875, depth 2.

```lisp
(seq
  (eat)
  (seq
    (unlink (self))
    (move
      (state ((state6 (target-bonds
          (scan
            (target-bonds (self))
            (target-bonds (do (eat) (none)))
          )
        )))
        (do
          (if true (photosynthesize) (nop))
          (min (energy) (color))
        )
      )
    )
  )
  (split)
  (photosynthesize)
)
```

## Variant 29962: 1062 living, 1341 births

Harvest 596109.2578125, depth 4.

```lisp
(seq
  (photosynthesize)
  (split)
  (give
    (if
      (let ((local6 (listen c3)))
        (if
          (if (not false) true true)
          (and false true)
          true
        )
      )
      (scan (age) (linked_temperature))
      (state ((state5 (linked_storage)))
        (scan-color (color) (storage))
      )
    )
    (energy)
  )
  (photosynthesize)
)
```

## Variant 14609: 518 living, 5725 births

Harvest 3004102.8984375, depth 2.

```lisp
(seq
  (turn (crowding))
  (photosynthesize)
  (state ((state6 (mod
      (mod
        (color)
        (random
          (min
            (random (age))
            (target-distance (none))
          )
        )
      )
      (max (sunlight-bearing) (linked_temperature))
    )))
    (seq (split) (eat))
  )
  (nop)
  (seq (photosynthesize) (move (age)))
  (color-set (generation))
)
```

## Variant 15565: 477 living, 1136 births

Harvest 910196.97265625, depth 2.

```lisp
(seq
  (seq (photosynthesize) (turn (rotation)))
  (move (target-storage (nearest-corpse)))
  (mobilize (target-tag (bond c1)))
  (split)
  (photosynthesize)
  (unlink
    (do
      (if (not false) (eat) (bud))
      (let ((local6 (if false (sunlight) (storage))))
        (none)
      )
    )
  )
)
```

## Variant 15383: 413 living, 1050 births

Harvest 875167.35546875, depth 3.

```lisp
(seq
  (state ((state1 (receive c1)))
    (do (photosynthesize) (split))
  )
  (if
    (<
      (let ((local5 (sunlight)))
        (sunlight-slope)
      )
      (tag)
    )
    (bud)
    (color-set (rotation))
  )
  (eat)
  (let ((local5 (target-bearing (bond c1))))
    (photosynthesize)
  )
)
```

## Variant 16502: 401 living, 1134 births

Harvest 850417.8125, depth 1.

```lisp
(seq
  (send (nearest-corpse) c0 (birth-result))
  (seq (photosynthesize) (nop))
  (eat)
  (let ((local5 (rotation)))
    (do (split) (photosynthesize))
  )
  (unlink
    (let ((local4 (tag)))
      (none)
    )
  )
  (state ((state4 (do (eat) (tag))))
    (turn (storage-bearing (sunlight-slope)))
  )
)
```

## Variant 14830: 348 living, 1528 births

Harvest 790784.0703125, depth 2.

```lisp
(seq
  (turn (listen c2))
  (photosynthesize)
  (state ((state6 (linked_temperature)))
    (seq (split) (eat))
  )
  (nop)
  (seq (photosynthesize) (move (age)))
  (color-set (generation))
)
```

## Variant 26825: 264 living, 307 births

Harvest 299240.50390625, depth 6.

```lisp
(seq
  (photosynthesize)
  (mobilize (target-storage (bond c0)))
  (split)
  (move (abs (target-distance (nearest-corpse))))
  (eat)
  (photosynthesize)
  (attack
    (none)
    (let ((local2 (target-bonds (none))))
      (age)
    )
  )
)
```

## Variant 26722: 261 living, 303 births

Harvest 257842.78515625, depth 2.

```lisp
(seq
  (set
    m7
    (target-color
      (let ((local0 (storage-slope (bonds))))
        (scan-color
          (mod
            (/ (storage) (rotation))
            (+ (linked_storage) (sunlight-bearing))
          )
          (target-color (self))
        )
      )
    )
  )
  (photosynthesize)
  (tag-set (linked_temperature))
  (split)
  (link (self))
  (photosynthesize)
)
```

## Variant 26805: 245 living, 274 births

Harvest 243260.8359375, depth 1.

```lisp
(seq
  (send (nearest-corpse) c0 (birth-result))
  (seq (photosynthesize) (nop))
  (eat)
  (let ((local5 (rotation)))
    (do (split) (photosynthesize))
  )
  (unlink
    (let ((local4 (tag)))
      (none)
    )
  )
  (state ((state4 (do (eat) (tag))))
    (turn (storage-bearing (sunlight-slope)))
  )
)
```
