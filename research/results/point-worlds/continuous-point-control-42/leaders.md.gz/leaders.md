## Variant 13919: 3215 living, 42201 births

Harvest 16693773.13671875, depth 1.

```lisp
(seq
  (attack (self) (linked_temperature))
  (eat)
  (photosynthesize)
  (move (color))
  (do (split) (photosynthesize))
)
```

## Variant 29287: 2815 living, 21562 births

Harvest 3853051.3125, depth 4.

```lisp
(seq
  (mobilize
    (target-temperature
      (do (tag-set (birth-result)) (self))
    )
  )
  (seq (eat) (photosynthesize))
  (bud)
  (store
    (state ((state4 (crowding)))
      (target-distance (nearest-cell))
    )
  )
  (photosynthesize)
)
```

## Variant 26720: 1452 living, 2030 births

Harvest 888311.4609375, depth 5.

```lisp
(seq
  (tag-set
    (let ((local4 (target-tag (bond c2))))
      (mod
        0.25
        (target-distance
          (if
            (or true (kin (self)))
            (self)
            (nearest-corpse)
          )
        )
      )
    )
  )
  (unlink
    (state ((state7 (temperature)))
      (nearest-corpse)
    )
  )
  (photosynthesize)
  (bud)
  (photosynthesize)
)
```

## Variant 28975: 1258 living, 1749 births

Harvest 598760.80859375, depth 2.

```lisp
(seq
  (photosynthesize)
  (move (mod (target-bearing (self)) (memory m1)))
  (split)
  (move
    (target-energy
      (do
        (state ((state3 (age)))
          (color-set (temperature))
        )
        (bond c2)
      )
    )
  )
  (eat)
  (photosynthesize)
)
```

## Variant 27595: 864 living, 1226 births

Harvest 557666.83203125, depth 2.

```lisp
(seq
  (photosynthesize)
  (move (memory m1))
  (do (split) (photosynthesize))
)
```

## Variant 26406: 582 living, 1020 births

Harvest 579185.5078125, depth 2.

```lisp
(seq
  (photosynthesize)
  (move (mod (target-bearing (self)) (memory m1)))
  (split)
  (seq
    (state ((state6 (storage)))
      (unlink (scan (crowding) (receive c0)))
    )
    (move (tag))
  )
  (eat)
  (photosynthesize)
)
```

## Variant 15865: 539 living, 9424 births

Harvest 3306213.92578125, depth 1.

```lisp
(seq
  (attack (self) (linked_temperature))
  (eat)
  (photosynthesize)
  (move (color))
  (do
    (split)
    (move
      (target-tag
        (if
          (state ((state0 (target-color (bond c1))))
            (<
              (birth-result)
              (state ((state3 (energy)))
                (bonds)
              )
            )
          )
          (do (photosynthesize) (none))
          (self)
        )
      )
    )
  )
)
```

## Variant 27311: 509 living, 1669 births

Harvest 631047.4453125, depth 2.

```lisp
(seq
  (photosynthesize)
  (move (mod (target-bearing (self)) (memory m1)))
  (split)
  (seq
    (state ((state6 (storage)))
      (unlink (scan (energy) (receive c0)))
    )
    (move (+ (energy) (sunlight-bearing)))
  )
  (eat)
  (photosynthesize)
)
```

## Variant 28487: 488 living, 533 births

Harvest 142365.203125, depth 2.

```lisp
(seq
  (photosynthesize)
  (move (mod (target-bearing (self)) (memory m1)))
  (split)
  (seq
    (state ((state6 (storage)))
      (unlink (scan (energy) (receive c0)))
    )
    (send (nearest-cell) c1 (listen c1))
  )
  (eat)
  (photosynthesize)
)
```

## Variant 28532: 387 living, 474 births

Harvest 107678.93359375, depth 3.

```lisp
(seq
  (seq (eat) (photosynthesize))
  (tag-set (target-storage (bond c1)))
  (let ((local3 (*
      (storage)
      (mod
        (mod
          (memory m2)
          (mod (birth-result) (receive c1))
        )
        (memory m1)
      )
    )))
    (bud)
  )
  (eat)
  (unlink (nearest-corpse))
  (photosynthesize)
)
```

## Variant 32806: 173 living, 182 births

Harvest 30384.70703125, depth 4.

```lisp
(seq
  (seq
    (send (self) c3 (receive c0))
    (photosynthesize)
  )
  (tag-set (target-storage (bond c1)))
  (let ((local3 (target-storage (bond c1))))
    (bud)
  )
  (eat)
  (unlink (nearest-corpse))
  (photosynthesize)
)
```

## Variant 26004: 168 living, 296 births

Harvest 109848.2421875, depth 4.

```lisp
(seq
  (tag-set
    (let ((local4 (target-tag (bond c2))))
      (bonds)
    )
  )
  (unlink
    (state ((state7 (temperature)))
      (nearest-corpse)
    )
  )
  (photosynthesize)
  (bud)
  (photosynthesize)
)
```
